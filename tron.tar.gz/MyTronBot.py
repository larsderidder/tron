#!/usr/bin/python

"""Template for your tron bot"""

import tron

import random

from collections import deque

def which_move(board):
	#file = open('debug.log', "a")
	#file.write("Begin!\n")
	
	if len(board.moves()) == 0:
		return tron.SOUTH
		
	if len(board.moves()) == 1:
		#file.write("quickchoice: " + str(board.moves()[0]) + "\n\n")
		return board.moves()[0]

	enemyReachable = []
	for dir in board.moves(board.them()):
		enemyReachable.append(board.rel(dir, board.them()))

	spaceCount = {}
	for dir in board.moves():
		dest = board.rel(dir)
		if dest in enemyReachable:
			spaceCount[dir] = -1
		else:
			spaceCount[dir] = floodfill(board, dest, [])
	
	#file.write("spacecount: " + str(spaceCount) + "\n")
	
	currentEnemySpace = floodfill(board, board.them(), [])
	#file.write("currentEnemySpace: " + str(currentEnemySpace) + "\n")

	enemySpaceCount = {}
	for dir in board.moves():
		myPos = board.rel(dir)
		enemySpaceCount[dir] = floodfill(board, board.them(), [myPos])
	
	#file.write("enemySpaceCount: " + str(enemySpaceCount) + "\n")
	
	bestchoices = []
	maxscore = -1
	for dir in spaceCount.keys():
		changeEnemySpace = currentEnemySpace - enemySpaceCount[dir]
		mySpace = spaceCount[dir]
		
		pathlength = 0
		origin = board.me()
		while board.passable(board.rel(dir, origin)) and pathlength <= 5:
			pathlength = pathlength + 1
			origin = board.rel(dir, origin)
		
		score = mySpace + changeEnemySpace + pathlength
		if score == maxscore:
			bestchoices.append(dir)
		elif score > maxscore:
			maxscore = score
			bestchoices = [dir]
	
	#file.write("bestchoices: " + str(bestchoices) + "\n")
	'''
	if len(bestchoices) == 1:
		return bestchoices[0]
	
	bestchoice = bestchoices[0]
	maxcount = 0
	for dir in bestchoices:
		count = 0
		origin = board.me()
		while board.passable(board.rel(dir, origin)):
			count = count + 1
			origin = board.rel(dir, origin)
		if count > maxcount:
			maxcount = count
			bestchoice = dir
	return bestchoice
	'''
	choice = random.choice(bestchoices)
	#file.write("choice: " + str(choice) + "\n\n")
	return choice

def floodfill(board, origin, visited):
	queue = deque()
	queue.append(origin)
	count = 0
	'''
	while len(queue) > 0:
		node = queue.popleft()
		count += 1
		visited.append(node)
		for dir in board.unvisitedMoves(node, visited):
			other = board.rel(dir, node)
			if other not in queue:
				queue.append(board.rel(dir, node))
	'''
	while len(queue) > 0:
		node = queue.pop()
		if node not in visited:
			continue
		west = node
		while board.passable(board.rel(tron.WEST, west)):
			west = board.rel(tron.WEST, west)
		east = node
		while board.passable(board.rel(tron.EAST, east)):
			east = board.rel(tron.EAST, east)
		
		westToEast = west
		while westToEast != board.rel(tron.EAST, east):
			north = board.rel(tron.NORTH, westToEast)
			if board.passable(north) and north not in visited:
				queue.append(north)
			south = board.rel(tron.SOUTH, westToEast)
			if board.passable(south) and south not in visited:
				queue.append(south)
			count += 1
			visited.append(westToEast)
			westToEast = board.rel(tron.EAST, westToEast)
	return count

# you do not need to modify this part
for board in tron.Board.generate():
    tron.move(which_move(board))
