import sys; sys.path.append('./')
import os
import imp
from copy import deepcopy
from time import time

try:
	from visualtron.pgu import gui
except:
	from pgu import gui
	
# py2exe screws up system fonts
#pygame.font.Font(filename, size)
	
def main_is_frozen():
   return (hasattr(sys, "frozen") or # new py2exe
           hasattr(sys, "importers") # old py2exe
           or imp.is_frozen("__main__")) # tools/freeze

def get_main_dir():
   if main_is_frozen():
       return os.path.dirname(sys.executable)
   return os.path.dirname(sys.argv[0])
	
import pygame
from pygame.locals import *
import argparse

from TronBoard import TronBoard
from PlayerFailedException import PlayerFailedException
from ProcessPlayer import ProcessPlayer
from BasicPythonPlayer import BasicPythonPlayer

def main():
    parser = argparse.ArgumentParser( 
                prog='VisualTron',
                formatter_class=argparse.RawDescriptionHelpFormatter,
                description="""
Runs a visual game of Tron using two agents.

Keyboard Controls:
    q - quit the program
    <space bar> - skip to the next game without finishing the current one, or start
        the next game if the current one is done
    [ - slow down the game
    ] - speed up the game

Example: python visualtron/VisualTron.py -n 2 -B maps/trix.txt 'ruby wallbot.rb' 'python wallbot.py'
         python visualtron/VisualTron.py -n 2 -B maps/trix.txt wallbot.py wallbot.py
         
The second example only works on Python bots as it loads them directly instead of 
using the interpreter and stdin/stdout. This requires the bot to define a 
which_move() function like the default example bots.
                """ )
    parser.add_argument('-B', '--boardfile', default='maps/trix.txt',
                        help='The boardfile to load in [default: maps/trix.txt]')
    parser.add_argument('-n', '--numgames', type=int, default=1,
                        help='Number of games to play [default: 1]')
    parser.add_argument('--autonext', action='store_true', default=False,
                        help='Automatically starts the next game after the current one is finished.')
    parser.add_argument('-s', '--speed', type=int, default=50,
                        help="Controls the speed of the games being played, should be between 1 and 999. Lowering it is not guaranteed to speed always things up. [default: 50]")
    parser.add_argument('player1cmd', metavar='Player 1 Command',
                        help='The command to run first player agent, or a python bot file.')
    parser.add_argument('player2cmd', metavar='Player 2 Command',
                        help='The command to run first player agent, or a python bot file.')
    args = parser.parse_args()
    
    if not (1 <= args.speed <= 999):
        print 'Invalid speed of [%s] should be between 1 and 999' % args.speed
        sys.exit()
    
    pygame.init()    

    vboard = VBoard(open(args.boardfile, 'r'))
    player1 = getPlayer(args.player1cmd, 1)
    player2 = getPlayer(args.player2cmd, 2)       
    vboard.setPlayers(player1, player2)
        
    pause_start = None
    quit = False
    for i in xrange(1, args.numgames+1):        
        vboard.setupGame(i)
        next_game = False
        while not (quit or next_game):            
            vboard.draw()
            if not vboard.is_gameover:
                vboard.movePlayers()
            else:
                if pause_start is None:
                    pause_start = time()
                if args.autonext and time() - pause_start > 1.2:
                    pause_start = None
                    next_game = True
    
            pygame.time.delay(args.speed)
            vboard.clear()
            
            event = pygame.event.poll()
            if event.type == KEYUP:
                if event.key == K_q:
                    quit = True
                elif event.key == K_SPACE:
                    next_game = True
                elif event.key == K_RIGHTBRACKET:
                    # speed up the game
                    args.speed = max(0, args.speed - 1)
                elif event.key == K_LEFTBRACKET:
                    # slow down the game
                    args.speed = min(999, args.speed + 1)
                    
            elif event.type == QUIT:
                quit = True
                
        if quit:
            break
                
            
def getPlayer(cmd, player_number):
    player = None
    if os.path.isfile(cmd) and os.path.splitext(cmd)[-1] == '.py':
        # assume its a python program that runs like the examples
        player = BasicPythonPlayer.getPlayer(cmd, player_number)
        
    if player is None:
        player = ProcessPlayer(cmd, cmd.split(' ')[-1], player_number)
        
    return player        
        
# Note that North and South appear to be swapped, but (0,0) is
# the top left corner, not bottom left.
DIR_TO_OFFSET = dict(N=(0, -1), E=(1, 0), S=(0, 1), W=(-1, 0))
DIR_TO_OFFSET[1]=(0, -1)
DIR_TO_OFFSET[2]=(1, 0)
DIR_TO_OFFSET[3]=(0, 1)
DIR_TO_OFFSET[4]=(-1, 0)

DIR_TO_STR = {1:'N', 2:'E', 3:'S', 4:'W'}

# Grid cell charaters
FLOOR = ' '
WALL  = '#'

# Setup some colors for the players
PLAYER1_TRAIL_COLOR = (255, 0, 0)
PLAYER1_BIKE_COLOR = (255, 192, 192)  
PLAYER2_TRAIL_COLOR = (0, 0, 255)
PLAYER2_BIKE_COLOR = (192, 192, 255)

WALL_COLOR = (128, 128, 128)
FLOOR_COLOR = (0, 0, 0)
        
class VBoard(object):
    def __init__(self, raw_board, scale=20):    
        # Read in the board file
        line = raw_board.readline().split()
        w, h = map(int, line)
        layout = []
        for i in xrange(h):
            layout.append([c for c in raw_board.readline().strip('\n')])
            
        self._board = layout
        self.board = deepcopy(layout)
        self.tron_board = TronBoard(w, h, self.board)
        
        self.boardsize = (w, h)
                
        # set the visual board up
        self.scale = scale
        wscaled = max(w*scale, 400)
        x_offset = (wscaled - w*scale) / 2
        self.size = (wscaled, h*scale)
        self.grid = []
        self.gridcells = pygame.sprite.RenderUpdates()
              
        # create all the grid tiles  
        for y, row in enumerate(layout):
            gridrow = []
            self.grid.append(gridrow)
            
            for x, cell in enumerate(row):  
                if cell == '1':
                    self.player1_pos = (x, y)
                elif cell == '2':
                    self.player2_pos = (x, y)
                    
                grid = Box(FLOOR_COLOR, (x_offset+x*scale, y*scale), scale)
                self.gridcells.add(grid)
                gridrow.append(grid)
                
        # control panel size and positioning
        self.control_size = (self.size[0], 40)
        self.control_corner = (0, self.size[1])
        self.control_rect = Rect(self.control_corner, self.control_size)
        
        # setup screen
        self.full_size = (self.size[0], self.size[1] + self.control_size[1])
        print 'fullsize:', self.full_size
        self.screen = pygame.display.set_mode(self.full_size)
        
        self.background = pygame.Surface(self.full_size)
        self.background.fill((128, 128, 128))  
              
        self.screen.blit(self.background, (0, 0))
        
        # control panel background to draw labels against
        self.control_background = pygame.Surface(self.control_size)
        self.control_background.fill((64, 64, 64))
        self.screen.blit(self.control_background, (0, self.size[1]))
        
        # setup control panel
        self.form = gui.Form()
        self.app = gui.App(theme=gui.Theme(dirs=os.path.join(get_main_dir(), 'data', 'themes', 'default')))
        self.control_panel = GameControl()
        c = gui.Container(align=-1, valign=-1)
        c.add(self.control_panel, 20, self.size[1])
        self.app.init(c)
        
    def setPlayers(self, player1, player2):
        # track the players
        self.player1 = player1
        self.player2 = player2
        self.player1_score = [0, 0, 0]
        self.player2_score = [0, 0, 0]
        self.players = [player1, player2]
        
        self.player1_move = None
        self.player2_move = None
        
        # set some colors for the players
        player1.trail_color = PLAYER1_TRAIL_COLOR
        player1.bike_color = PLAYER1_BIKE_COLOR
        
        player2.trail_color = PLAYER2_TRAIL_COLOR        
        player2.bike_color = PLAYER2_BIKE_COLOR 
        
        player1.pos = self.player1_pos
        player2.pos = self.player2_pos
        
        # update gui
        self.control_panel.player1_label.value = self.player1.name
        self.control_panel.player2_label.value = self.player2.name
        
    def setupGame(self, game_number):
        pygame.display.set_caption('Game %s' % game_number)
        
        self.game_number = game_number
        self.is_gameover = False
        self.final_move = False

        self.player1_move = None
        self.player2_move = None
        self.player1.pos = self.player1_pos
        self.player2.pos = self.player2_pos
                
        for player in self.players:
            player.resetPlayer()
        
        for y, row in enumerate(self._board):
            for x, cell in enumerate(row):
                if cell == WALL:
                    color = WALL_COLOR
                    
                elif cell == '1':
                    color = PLAYER1_BIKE_COLOR
                    
                elif cell == '2':
                    color = PLAYER2_BIKE_COLOR
                
                else:
                    color = FLOOR_COLOR
                    
                self.grid[y][x].setColor(color)  
                
        self.board = deepcopy(self._board)
        w,h = self.boardsize
        self.tron_board = TronBoard(w, h, self.board)
                
    def movePlayers(self):
        if self.player1_move is None:
            try:
                self.player1_move = self.player1.getMove(self)
            except PlayerFailedException, err:
                print 'P1:', err
                self.player1.dead = True
                self.gameover()
            
        if self.player2_move is None:
            try:
                self.player2_move = self.player2.getMove(self)
            except PlayerFailedException, err:
                print 'P2:', err
                self.player2.dead = True
                self.gameover()
            
        if self.player1_move is None or self.player2_move is None:
            return
        
        #print 'p1:', DIR_TO_STR.get(self.player1_move, self.player1_move), '\tp2:', DIR_TO_STR.get(self.player2_move, self.player2_move)
            
            
        # update player 1 position
        x1, y1 = self.player1.pos
        nx1, ny1 = x1 + DIR_TO_OFFSET[self.player1_move][0], y1 + DIR_TO_OFFSET[self.player1_move][1]
        
        # update player 2 position
        x2, y2 = self.player2.pos
        nx2, ny2 = x2 + DIR_TO_OFFSET[self.player2_move][0], y2 + DIR_TO_OFFSET[self.player2_move][1]
        
        # check to see if its a valid board position
        moves = ((self.player1, x1, y1, nx1, ny1), (self.player2, x2, y2, nx2, ny2))
        for player, x, y, nx, ny in moves:
            try:
                cell = self.board[ny][nx]
            except IndexError, err:
                print 'P%s: Illegal move out of bounds (%s, %s)' % (player.player_number, nx, ny)
                player.dead = True
                self.gameover()
                return
                
            if cell == WALL:
                print 'P%s: Moved into wall (%s, %s)' % (player.player_number, nx, ny)
                player.dead = True
                self.gameover() 
                return
            
        for player, x, y, nx, ny in moves:
            # update board state
            self.board[y][x] = WALL
            self.board[ny][nx] = str(player.player_number)
            
            # update gui state
            self.grid[y][x].setColor(player.trail_color)
            self.grid[ny][nx].setColor(player.bike_color)
        
            # update player state
            player.pos = (nx, ny)
            
        # check to see if they ran into each other (tried to move into the same square),
        # which is a tie, we check after the move so we get the nice crash
        if nx1 == nx2 and ny1 == ny2:
            self.player1.dead = True
            self.player2.dead = True
            # crash color
            self.grid[ny1][nx1].setColor((255,255,255))
            self.gameover()        
            return
        
        # clear the move so that a new one can be made
        self.player1_move = None
        self.player2_move = None

    def gameover(self):    
        if self.player1.dead and self.player2.dead:
            winner = None
            loser = None
            self.player1_score[2] += 1
            self.player2_score[2] += 1
        elif self.player1.dead:
            loser = self.player1
            winner = self.player2
            self.player1_score[1] += 1
            self.player2_score[0] += 1
        elif self.player2.dead:
            loser = self.player2
            winner = self.player1
            self.player1_score[0] += 1
            self.player2_score[1] += 1
            
        print '='*5, 'Game %s' % self.game_number, '='*5
        if winner is None:
            print 'Game over!'
            print 'Tie'
            pygame.display.set_caption('Game %s -- Tie' % self.game_number)
        else:
            print 'Winner:', winner.name
            print 'Loser:', loser.name
            color = 'Red' if winner.player_number == 1 else 'Blue'
            pygame.display.set_caption('Game %s -- %s Wins (%s) ' % (self.game_number, winner.name, color))
        
        print 'Player 1: W: %i, L: %i, T: %i' % tuple(self.player1_score)
        print 'Player 2: W: %i, L: %i, T: %i' % tuple(self.player2_score)
        print
        
        self.control_panel.player1_score_label.value = 'W: %i, L: %i, T: %i' % tuple(self.player1_score)
        self.control_panel.player2_score_label.value = 'W: %i, L: %i, T: %i' % tuple(self.player2_score)
        
        self.player1.gameover()
        self.player2.gameover()
        self.is_gameover = True
        
    def draw(self):
        rectlist = self.gridcells.draw(self.screen)
        self.screen.blit(self.control_background, self.control_corner)
        self.app.paint(self.screen)
        rectlist.append(self.control_rect)
        pygame.display.update(rectlist)
        #pygame.display.flip()
        
                
    def clear(self):
        self.gridcells.clear(self.screen, self.background)

    
class Box(pygame.sprite.Sprite):
    def __init__(self, color, pos, size):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface((size, size))
        self.image.fill(color)
        self.rect = self.image.get_rect()
        self.rect.topleft = pos
        
    def setColor(self, color):
        self.image.fill(color)
        
class GameControl(gui.Table):
    def __init__(self,**params):
        gui.Table.__init__(self,**params)   
        
        fg = (255, 255, 255)
        
        spacer = ' ' * 30
        
        self.tr()
        self.td(gui.Label("Red: ",color=fg),align=1)
        self.player1_label = gui.Label(spacer,color=fg)
        self.td(self.player1_label)
        self.player1_score_label = gui.Label('W: 99, L: 99, T: 99', color=fg)
        self.player1_score_label.value = 'W: 0, L: 0, T: 0'
        self.td(self.player1_score_label, align=1)
        
        self.tr()
        self.td(gui.Label("Blue: ",color=fg),align=1)
        self.player2_label = gui.Label(spacer, color=fg)
        self.td(self.player2_label)  
        self.player2_score_label = gui.Label('W:  99, L:  99, T: 99', color=fg)
        self.player2_score_label.value = 'W: 0, L: 0, T: 0'
        self.td(self.player2_score_label, align=1)   
        
if __name__ == '__main__':
    main()