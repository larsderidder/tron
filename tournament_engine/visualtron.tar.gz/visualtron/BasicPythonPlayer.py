import sys
import os
from time import time

MOVES_TO_DIR = {'1':'N', '2':'E', '3':'S', '4':'W'}
    
from PlayerFailedException import PlayerFailedException

# we have to play dirty with the import process to avoid importing the normal 'tron.py'
# instead we want our own special module
class TronImportKiller(object):
    def __init__(self):
        pass
    
    def find_module(self, fullname, path=None):
        if fullname.split('.')[-1] == 'tron':
            return self
        return None
    
    def load_module(self, fullname):
        class DummyBoard(object):
            @staticmethod
            def generate():
                return []
                
        class DummyTron(object):
            """Dummy tron module"""
            def __init__(self):
                self.__file__ = '<DummyTron>'
                self.__name__ = '<DummyTron>'
                
                self.Board = DummyBoard
                self.NORTH = 1
                self.EAST  = 2
                self.SOUTH = 3
                self.WEST  = 4
                self.FLOOR = ' '
                self.WALL  = '#'
                self.ME    = '1'
                self.THEM  = '2'
                
                self.DIRECTIONS = (self.NORTH, self.EAST, self.SOUTH, self.WEST)
                
        mod = DummyTron()
        return mod

# attach import hook
sys.meta_path.append(TronImportKiller())


class BasicPythonPlayer(object):
    """A tron player that loads in a python player module that uses the module
    level function which_move() to return the move the player wants to make."""
    
    def __init__(self, player_module, name, player_number):
        """Create a basic tron player from a python module. 
        
        Note: It is suggested that you use BasicPythonPlayer.getPlayer() instead of creating
        this class manually. 
        
        :param player_module: the module which contains the decision making code of the player
        :param name: the players name
        :param player_number: either 1, 2 depending if the player is the first or second player respectively
        """

        self.player_number = player_number
        self.name = name
        self.player_module = player_module
        self.dead = False
        
    def resetPlayer(self):
        self.dead = False
        mod_name = self.player_module.__name__
        sys.modules.pop(mod_name, None)
        self.player_module = __import__(mod_name)   
        
    @staticmethod
    def getPlayer(mod_path, player_number):
        """Given the path to a python module attempt to load it as a BasicPythonPlayer object, if 
        it fails return none.
        
        :param mod_path: the path the python module to load
        :param player_number: the number of this player, either 1 or 2
        
        :returns: a BasicPythonPlayer object if successful, or None if something went wrong
        """
        
        # need to make sure the current working directory is in the path
        cur_dir = os.path.abspath(os.curdir)
        if cur_dir not in sys.path:
            sys.path.append(cur_dir)

            # extract just the module name
        mod_name = os.path.splitext(os.path.basename(mod_path))[0]
        
        # force a reload of the agent module in case the declared module level objects
        sys.modules.pop(mod_name, None)        
        player_module = __import__(mod_name)
        
        # if it doesn't have a the correct function, its not a usable module
        if not hasattr(player_module, 'which_move'):
            return None
        
        # we are playing fast and dirty with the player module to trick it into 
        # thinking things
        player_module.tron.ME = str(player_number)
        player_module.tron.THEM = '1' if player_number == 2 else '2'
        
        # players name
        name = mod_name.split('.')[-1]
        
        return BasicPythonPlayer(player_module, name, player_number)
        
    def getMove(self, vboard):
        """Return the player's move for the state of the given VisBoard.
        
        :param visboard: board object to get the next move for
        
        :returns: a single char (N, S, E, W) of the players move, or None if player needs more time
        """
        
        #print 
        #print 'Player', self.player
        #print '\n'.join((''.join(row) for row in vboard.tron_board.board))
                
        # update the tron board
        pos = self.pos
        vboard.tron_board._me = (pos[1], pos[0])
        vboard.board[pos[1]][pos[0]]  = '1'
        
        pos = vboard.players[self.player_number % 2].pos
        vboard.tron_board._them = (pos[1], pos[0])
        vboard.board[pos[1]][pos[0]]  = '2'
        
        return self.player_module.which_move(vboard.tron_board)
            
    def gameover(self):
        """Kill the player process now that the game is over."""
        
        pass