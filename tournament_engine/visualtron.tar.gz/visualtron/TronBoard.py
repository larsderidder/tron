
# If you want to use this file, make sure to include it in your
# submission. You may modify it and submit the modified copy, or you
# may discard it and roll your own.
class TronBoard(object):
    """The Tron Board.

    The recommended way to use this class is as follows:

        def which_move(board):
            # figure this part out yourself
            return tron.NORTH

        for board in tron.Board.generate():
            tron.move(which_move(board))

    Feel free to add stuff to this class.
    """
    
    NORTH = 1
    EAST  = 2
    SOUTH = 3
    WEST  = 4
    
    FLOOR = ' '
    WALL  = '#'
    ME    = '1'
    THEM  = '2'
    
    DIRECTIONS = (NORTH, EAST, SOUTH, WEST)

    def __init__(self, width, height, board):
        """You do not need to call this method directly."""

        self.board = board
        self.height = height
        self.width = width
        self._me = None
        self._them = None

    def __getitem__(self, coords):
        """Retrieve the object at the specified coordinates.

        Use it like this:

            if board[3, 2] == tron.THEM:
                # oh no, the other player is at (3,2)
                run_away()

        Coordinate System:
            The coordinate (y, x) corresponds to row y, column x.
            The top left is (0, 0) and the bottom right is
            (board.height - 1, board.width - 1). Out-of-range
            coordinates are always considered walls.

        Items on the board:
            tron.FLOOR - an empty square
            tron.WALL  - a wall or trail of a bot
            tron.ME    - your bot
            tron.THEM  - the enemy bot
        """

        y, x = coords
        if not 0 <= x < self.width or not 0 <= y < self.height:
            return TronBoard.WALL
        return self.board[y][x]

    def me(self):
        """Finds your position on the board.

        It is always true that board[board.me()] == tron.ME.
        """

        if not self._me:
            self._me = self.find(TronBoard.ME)
        return self._me

    def them(self):
        """Finds the other player's position on the board.

        It is always true that board[board.them()] == tron.THEM.
        """

        if not self._them:
            self._them = self.find(TronBoard.THEM)
        return self._them

    def find(self, obj):
        """You do not need to call this method directly."""

        for y in xrange(self.height):
            for x in xrange(self.width):
                if self[y, x] == obj:
                    return y, x
        raise KeyError("object '%s' is not in the board" % obj)

    def passable(self, coords):
        """Determine if a position in the board is passable.

        You can only safely move onto passable tiles, and only
        floor tiles are passable.
        """

        return self[coords] == TronBoard.FLOOR

    def rel(self, direction, origin=None):
        """Calculate which tile is in the given direction from origin.

        The default origin is you. Therefore, board.rel(tron.NORTH))
        is the tile north of your current position. Similarly,
        board.rel(tron.SOUTH, board.them()) is the tile south of
        the other bot's position.
        """

        if not origin:
            origin = self.me()
        y, x = origin
        if direction == TronBoard.NORTH:
            return y - 1, x
        elif direction == TronBoard.SOUTH:
            return y + 1, x
        elif direction == TronBoard.EAST:
            return y, x + 1
        elif direction == TronBoard.WEST:
            return y, x - 1
        else:
            raise KeyError("not a valid direction: %s" % direction)

    def adjacent(self, origin):
        """Calculate the four tiles that are adjacent to origin.

        Particularly, board.adjacent(board.me()) returns the four
        tiles to which you can move to this turn. This does not
        return tiles diagonally adjacent to origin.
        """

        return [self.rel(dir, origin) for dir in TronBoard.DIRECTIONS]

    def moves(self):
        """Calculate which moves are safe to make this turn.

        Any move in the returned list is a valid move. There
        are two ways moving to one of these tiles could end
        the game:

            1. At the beginning of the following turn,
               there are no valid moves off this tile.
            2. The other player also moves onto this tile,
               and you collide.
        """
        possible = dict((dir, self.rel(dir)) for dir in TronBoard.DIRECTIONS)
        passable = [dir for dir in possible if self.passable(possible[dir])]
        if not passable:
            # it seems we have already lost
            return [TronBoard.NORTH]
        return passable