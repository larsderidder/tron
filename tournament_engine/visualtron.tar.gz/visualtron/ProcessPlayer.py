import os
import signal
from subprocess import Popen, PIPE
from time import time
import string

MOVES_TO_DIR = {'1':'N', '2':'E', '3':'S', '4':'W'}
    
from PlayerFailedException import PlayerFailedException 

class ProcessPlayer(object):
    """Basic tron player that talks over stdout/stdin with a player process."""
    
    def __init__(self, cmd, name, player_number):
        """Create a basic tron player in a subprocess.
        
        :param cmd: the command to run that will start the subprocess of the player, 
                    example "python some/dir/wallbot.py"
        :param name: the players name
        :param player: either 1, 2 depending if the player is the first or second player respectively
        """

        self.name = name
        self.player_number = player_number
        self.dead = False
        
        # open up the process
        self.cmd = cmd
        self.process = Popen(cmd, shell=use_shell, stdin=PIPE, stdout=PIPE)

        # create our translation tables for creating the correct board representation
        # to send to the player process
        if player_number == 1:
            self.trans = string.maketrans('12', '12')
        else:
            self.trans = string.maketrans('12', '21')

        # player is ready to make a move            
        self.state = 'ready'   
        
    def resetPlayer(self):
        self.process = Popen(self.cmd, shell=use_shell, stdin=PIPE, stdout=PIPE) 
        
    def _writeLine(self, txt):
        """Write a line to stdin of the process (appends newline character to the string).
        
        :param txt: the text/string to write out to stdin
        """
        
        self.process.stdin.write(txt)
        self.process.stdin.write('\n')
        
    def _readChar(self):
        """Attempt to read a single character from the process's stdout
        
        :returns: a single char or None if nothing was read
        """
        
        return self.process.stdout.read(1)
        
    def _flush(self):
        """Flush stdin of the process to ensure things were written to it."""
        
        self.process.stdin.flush()

    def getMove(self, visboard):
        """Return the player's move for the state of the given VisBoard.
        
        :param visboard: board object to get the next move for
        
        :returns: a single char (N, S, E, W) of the players move, or None if player needs more time
        """
        
        if self.state == 'ready':
            self.state = 'sending board'
            
            # translate the board and send it the player process
            self._writeLine('%s %s' % visboard.boardsize)
            for row in visboard.board:
                l = string.translate(''.join(row), self.trans)
                self._writeLine(l)
            self._flush()
            
            # board sent, now we can wait
            self.state = 'waiting on move'
            
            # track when we started so we can error if it takes to long to move
            self.start_waiting = time()
            return None
            
        if self.state == 'waiting on move':
            # if we've been waiting to long on the player process to return a move
            # throw an error
            if time() - self.start_waiting > 1000:
                self.state = 'player failed'
                raise PlayerFailedException('%s: Player took to long to make move' % self.name)
                
            # attempt to read a char from the player process, if we don't get
            # anything just return
            move = self._readChar()
            if move is None or len(move.strip()) == 0: 
                return None

            # make sure its a valid move            
            if move not in MOVES_TO_DIR:
                self.state = 'player failed'
                raise PlayerFailedException('%s: Returned invalid move [%s]' % (self.name, move))
            
            # a good move was returned, so we are ready to make another move
            self.state = 'ready'
            return MOVES_TO_DIR[move]
        
        else:
            return None
            
    def gameover(self):
        """Kill the player process now that the game is over."""
        
        if hasattr(signal, 'SIGKILL'):
            sig = signal.SIGKILL
        else:
            sig = signal.SIGTERM
            
        if self.process.poll() is None:
            try:
                kill(self.process.pid, sig)
            except:
                return False    
                
# determine how we handle subprocesses based on the OS we are running on   
# shamelessly borrowed from: nneonneo's python tournament code          
if not hasattr(os, 'kill'):
    try:
        import win32api
    except ImportError:
        print "Warning: System does not support kill(); process may end up spinning upon process exit."
    def kill(pid, sig=signal.SIGTERM):
        # http://www.python.org/doc/faq/windows/
        import win32api
        if sig != signal.SIGTERM:
            raise OSError("Sending any signal except SIGTERM is not supported on Windows.")
        handle = win32api.OpenProcess(1, 0, pid)
        return (0 != win32api.TerminateProcess(handle, 0))
    use_shell = True
else:
    kill = os.kill
    use_shell = True                