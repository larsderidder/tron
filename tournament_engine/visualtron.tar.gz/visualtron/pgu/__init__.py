"""Phil's pyGame Utilities


"""
__version__ = '0.12.3'

# vim: set filetype=python sts=4 sw=4 noet si :
